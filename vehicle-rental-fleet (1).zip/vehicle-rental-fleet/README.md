# Vehicle Rental & Fleet Optimization System: Registration & Login

Java 11 · Servlets (javax.*) · JSP/JSTL · JDBC · MySQL 8 · Maven WAR · Apache Tomcat 9

> **Status: SOURCE AUDIT COMPLETE, runtime verification incomplete.**
> The build environment used to prepare this ZIP had no access to Maven Central, MySQL or Tomcat, so
> `mvn package`, JSP compilation, database access and a live Tomcat run have **not** been executed. See "Test report".

## 1. Prerequisites
| Item | Version |
|---|---|
| JDK | 11 (Eclipse: Window > Preferences > Java > Installed JREs) |
| Maven | 3.8+ (or Eclipse's embedded m2e) |
| MySQL | 8.x |
| Tomcat | **9.x** (not 10+/11: they use `jakarta.*` and will not load this WAR) |

## 1b. Fastest way: Docker (no Java, Maven, Tomcat or MySQL install)
```
docker compose up --build
```
Open `http://localhost:8080/fleet/`. Compose starts MySQL 8 (schema loaded automatically from `sql/schema.sql`)
and builds and runs the WAR on Tomcat 9. Stop with `Ctrl+C`; `docker compose down -v` also wipes the database.
Docker files were written without being run in the preparation environment (no Docker daemon there).

## 2. Database (manual setup)
```
mysql -u root -p < sql/schema.sql
```
Creates database `fleet_db` and table `users`. Then point the app at your MySQL, either by editing
`src/main/resources/db.properties` or (preferred) by setting environment variables before starting Tomcat:
`DB_URL`, `DB_USER`, `DB_PASSWORD` (see `.env.example`). In Eclipse set them under
Run > Run Configurations > Apache Tomcat > Environment.

First administrator: register normally, then
`UPDATE users SET role='ADMIN' WHERE email='you@example.com';`
Public registration only ever creates `CUSTOMER` accounts.

## 3. Import into Eclipse
1. File > Import > Maven > **Existing Maven Projects** > select this folder > Finish.
2. Right-click project > Maven > Update Project (Force Update).
3. Window > Preferences > Server > Runtime Environments > Add **Apache Tomcat v9.0**.
4. Right-click project > Run As > Run on Server > Tomcat 9.
5. Open `http://localhost:8080/fleet/` (context path = `<finalName>` in `pom.xml`; with Run on Server Eclipse may
   use `/vehicle-rental-fleet`. Check the URL shown in the Eclipse browser tab or Server > Modules > Path).

## 4. Command-line build
```
mvn clean package          # -> target/fleet.war
cp target/fleet.war $CATALINA_HOME/webapps/
$CATALINA_HOME/bin/startup.sh   # logs: $CATALINA_HOME/logs/catalina.out
```

## 5. Routes
| Route | Method | Access | Purpose |
|---|---|---|---|
| `/` | GET | public | redirects to `/login` |
| `/register` | GET, POST | public | create CUSTOMER account |
| `/login` | GET, POST | public | sign in |
| `/dashboard` | GET | signed-in | landing page (`AuthFilter`) |
| `/logout` | POST | signed-in | sign out (GET redirects to `/login`) |
| anything else | any | n/a | real 404 page |

## 6. What the code does
- Passwords: PBKDF2-HMAC-SHA256, 210,000 iterations, per-user salt, constant-time compare.
- All SQL uses prepared statements; duplicate e-mails are rejected by the `UNIQUE` index (HTTP 409).
- CSRF token on every POST; expired token redirects back to the form instead of a bare 403.
- Session fixation defence (new session on login), HttpOnly + SameSite=Lax cookie, cookie-only session tracking.
- Login throttle: 5 failed attempts per address+e-mail per 15 min, then HTTP 429 (in-memory, resets on restart).
- Unknown e-mail still performs a hash check so timing does not reveal valid accounts.
- Status codes: 400 validation, 401 bad credentials, 403 suspended, 409 duplicate, 429 throttled, 503 database down.
- Error pages show no stack traces; server-side details go to the Tomcat log.

## 7. Test report (honest)
Executed in the preparation environment:

| Feature | Test performed | Result | Evidence / limitation |
|---|---|---|---|
| Java compilation | `javac` of all `src/main/java` against hand-written javax.servlet API **stubs** | PASS | exit 0. Proves syntax and types only; the real API jars were unavailable |
| Password hashing | verify correct / wrong / malformed hash, salt uniqueness | PASS | 4 checks |
| Login throttle | block after 5 failures, window expiry, reset | PASS | 8 checks |
| CSRF expiry handling | POST without token on `/login`, `/register` | PASS | redirect to `?expired=1` (servlet driven through proxy fakes) |
| Registration validation | bad name/e-mail/password/confirm | PASS | HTTP 400, four field errors, password not echoed |
| Login throttling at servlet level | 5 recorded failures then POST | PASS | HTTP 429, no DB access |
| Background grid (JS) | rendered in Chromium, pointer + drift, no console errors | PASS | static preview of login page |
| `mvn clean verify` / `package` | not run | BLOCKED | Maven Central unreachable (HTTP 403 from egress policy) |
| JSP compilation | not run | BLOCKED | needs Tomcat/Jasper |
| web.xml / context.xml parsing | not run | BLOCKED | needs Tomcat |
| MySQL schema creation | not run | BLOCKED | no MySQL server available |
| Registration persisted to DB | not run | BLOCKED | no MySQL |
| Login against stored hash | not run | BLOCKED | no MySQL |
| Duplicate e-mail (HTTP 409) | not run | BLOCKED | needs MySQL error 1062 |
| Database unavailable (HTTP 503) | not run | NOT TESTED | needs a JDBC driver and MySQL |
| Session expiry, role access, logout | not run | BLOCKED | needs Tomcat |
| End-to-end browser flow | not run | BLOCKED | needs Tomcat + MySQL |

Please run the BLOCKED rows on your machine once; section 8 lists the quick checks.

## 8. Quick smoke test after deployment
1. `/` redirects to `/login`. 2. Register `test@example.com` / `Test1234`: you land on `/login` with a green notice.
3. `SELECT user_id,email,role,LEFT(password_hash,12) FROM fleet_db.users;` shows the row with `pbkdf2$210000`.
4. Register the same e-mail again: "already exists". 5. Sign in: dashboard shows your name and `CUSTOMER`.
6. Open `/fleet/dashboard` in a private window: redirected to `/login`. 7. Sign out, press Back: no cached dashboard.
8. Five wrong passwords: the sixth attempt shows "Too many failed attempts". 9. `/fleet/nope` shows the 404 page.

## 9. Troubleshooting
| Symptom | Cause / fix |
|---|---|
| HTTP 404 on every URL | wrong context path; see section 3 step 5 |
| `ClassNotFoundException: javax.servlet...` or `jakarta` errors | Tomcat 10+ in use; install Tomcat 9 |
| `Communications link failure`, `Access denied for user` | wrong `DB_URL`/user/password, or MySQL not running |
| `Unknown database 'fleet_db'` | run `sql/schema.sql` |
| `Unable to load class com.mysql.cj.jdbc.Driver` | the WAR lacks the connector; run `mvn clean package`, check `WEB-INF/lib` |
| Sign-in page says "Your page expired" | session timed out (30 min) or cookies blocked |
| Styles missing | Bootstrap loads from jsDelivr; the browser needs internet access |

## 10. Known limitations
- Only registration, login, logout and a landing dashboard exist. Vehicle, booking, maintenance and report modules from the synopsis are not built.
- Roles are stored and shown, but no role-restricted pages exist yet (`AuthFilter` is ready for `/app/*`).
- Plain `DriverManager` connections (no pool); fine for a coursework load, add HikariCP for production.
- Throttle is in memory and per server instance. No e-mail verification or password reset.
