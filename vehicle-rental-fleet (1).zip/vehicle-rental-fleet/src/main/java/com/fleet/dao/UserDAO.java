package com.fleet.dao;

import com.fleet.model.User;
import com.fleet.util.DBUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** All SQL for the users table. Prepared statements only. */
public class UserDAO {

    private static final int MYSQL_DUPLICATE_ENTRY = 1062;

    /** Thrown when the e-mail is already registered. */
    public static class DuplicateEmailException extends Exception {
        private static final long serialVersionUID = 1L;
    }

    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT user_id, name, email, password_hash, role, status, created_at "
                   + "FROM users WHERE email = ?";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return null;
                }
                User u = new User();
                u.setUserId(rs.getInt("user_id"));
                u.setName(rs.getString("name"));
                u.setEmail(rs.getString("email"));
                u.setPasswordHash(rs.getString("password_hash"));
                u.setRole(rs.getString("role"));
                u.setStatus(rs.getString("status"));
                u.setCreatedAt(rs.getTimestamp("created_at"));
                return u;
            }
        }
    }

    /** Creates a CUSTOMER account. Relies on the UNIQUE index, so concurrent sign-ups can't race. */
    public int createCustomer(String name, String email, String passwordHash)
            throws SQLException, DuplicateEmailException {
        String sql = "INSERT INTO users (name, email, password_hash, role, status) "
                   + "VALUES (?, ?, ?, 'CUSTOMER', 'ACTIVE')";
        try (Connection c = DBUtil.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, passwordHash);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : -1;
            }
        } catch (SQLException e) {
            if (e.getErrorCode() == MYSQL_DUPLICATE_ENTRY) {
                throw new DuplicateEmailException();
            }
            throw e;
        }
    }
}
