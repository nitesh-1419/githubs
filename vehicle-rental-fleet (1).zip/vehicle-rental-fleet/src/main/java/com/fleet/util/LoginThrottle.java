package com.fleet.util;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory brute-force guard: at most MAX_FAILURES failed sign-ins per key
 * (client address + e-mail) inside WINDOW_MS. State resets on server restart and is
 * per-JVM; use a shared store if the app is ever clustered.
 */
public final class LoginThrottle {

    static final int MAX_FAILURES = 5;
    static final long WINDOW_MS = 15 * 60 * 1000L;
    private static final int CLEANUP_THRESHOLD = 5000;

    private static final ConcurrentHashMap<String, Deque<Long>> FAILURES = new ConcurrentHashMap<>();

    private LoginThrottle() {
    }

    public static boolean isBlocked(String key) {
        return isBlocked(key, System.currentTimeMillis());
    }

    static boolean isBlocked(String key, long now) {
        Deque<Long> d = FAILURES.get(key);
        if (d == null) {
            return false;
        }
        synchronized (d) {
            prune(d, now);
            return d.size() >= MAX_FAILURES;
        }
    }

    public static void recordFailure(String key) {
        recordFailure(key, System.currentTimeMillis());
    }

    static void recordFailure(String key, long now) {
        if (FAILURES.size() > CLEANUP_THRESHOLD) {
            FAILURES.entrySet().removeIf(e -> {
                synchronized (e.getValue()) {
                    prune(e.getValue(), now);
                    return e.getValue().isEmpty();
                }
            });
        }
        Deque<Long> d = FAILURES.computeIfAbsent(key, k -> new ArrayDeque<>());
        synchronized (d) {
            prune(d, now);
            d.addLast(now);
        }
    }

    public static void reset(String key) {
        FAILURES.remove(key);
    }

    private static void prune(Deque<Long> d, long now) {
        while (!d.isEmpty() && now - d.peekFirst() > WINDOW_MS) {
            d.removeFirst();
        }
    }
}
