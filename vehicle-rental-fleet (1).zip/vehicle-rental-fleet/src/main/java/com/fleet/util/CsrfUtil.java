package com.fleet.util;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/** Synchronizer-token CSRF protection for every state-changing POST. */
public final class CsrfUtil {

    public static final String ATTR = "csrfToken";
    public static final String PARAM = "_csrf";
    private static final SecureRandom RANDOM = new SecureRandom();

    private CsrfUtil() {
    }

    /** Ensures the session holds a token and exposes it to the JSP as ${csrfToken}. */
    public static void issue(HttpServletRequest req) {
        HttpSession session = req.getSession(true);
        String token = (String) session.getAttribute(ATTR);
        if (token == null) {
            byte[] b = new byte[32];
            RANDOM.nextBytes(b);
            token = Base64.getUrlEncoder().withoutPadding().encodeToString(b);
            session.setAttribute(ATTR, token);
        }
        req.setAttribute(ATTR, token);
    }

    public static boolean isValid(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) {
            return false;
        }
        String expected = (String) session.getAttribute(ATTR);
        String actual = req.getParameter(PARAM);
        return expected != null && actual != null
                && MessageDigest.isEqual(expected.getBytes(), actual.getBytes());
    }
}
