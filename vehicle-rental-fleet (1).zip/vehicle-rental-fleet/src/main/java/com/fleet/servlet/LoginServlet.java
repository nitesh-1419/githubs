package com.fleet.servlet;

import com.fleet.dao.UserDAO;
import com.fleet.model.User;
import com.fleet.util.CsrfUtil;
import com.fleet.util.LoginThrottle;
import com.fleet.util.PasswordUtil;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = Logger.getLogger(LoginServlet.class.getName());
    private static final String VIEW = "/WEB-INF/views/login.jsp";

    private final transient UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession existing = req.getSession(false);
        if (existing != null && existing.getAttribute("userId") != null) {
            resp.sendRedirect(req.getContextPath() + "/dashboard");
            return;
        }
        CsrfUtil.issue(req);
        if ("1".equals(req.getParameter("registered"))) {
            req.setAttribute("success", "Account created. Sign in to continue.");
        } else if ("1".equals(req.getParameter("loggedout"))) {
            req.setAttribute("success", "You have been signed out.");
        } else if ("1".equals(req.getParameter("expired"))) {
            req.setAttribute("error", "Your page expired. Please sign in again.");
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        if (!CsrfUtil.isValid(req)) {
            // Usually an expired session; send the user back to a fresh form instead of a bare 403.
            resp.sendRedirect(req.getContextPath() + "/login?expired=1");
            return;
        }

        String email = req.getParameter("email") == null ? "" : req.getParameter("email").trim().toLowerCase(Locale.ROOT);
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");
        String throttleKey = req.getRemoteAddr() + "|" + email;

        int status = HttpServletResponse.SC_UNAUTHORIZED;
        String error = null;

        if (LoginThrottle.isBlocked(throttleKey)) {
            status = 429;
            error = "Too many failed attempts. Try again in a few minutes.";
        } else {
            try {
                User user = userDAO.findByEmail(email);
                if (user == null) {
                    PasswordUtil.verifyDummy(password);
                    error = "Incorrect e-mail or password.";
                } else if (!PasswordUtil.verify(password, user.getPasswordHash())) {
                    error = "Incorrect e-mail or password.";
                } else if (!"ACTIVE".equals(user.getStatus())) {
                    status = HttpServletResponse.SC_FORBIDDEN;
                    error = "This account is suspended. Contact the administrator.";
                } else {
                    LoginThrottle.reset(throttleKey);
                    // Session fixation defence: discard the pre-login session, start a fresh one.
                    HttpSession old = req.getSession(false);
                    if (old != null) {
                        old.invalidate();
                    }
                    HttpSession session = req.getSession(true);
                    session.setAttribute("userId", user.getUserId());
                    session.setAttribute("userName", user.getName());
                    session.setAttribute("userRole", user.getRole());
                    CsrfUtil.issue(req);
                    resp.sendRedirect(req.getContextPath() + "/dashboard");
                    return;
                }
                if (status == HttpServletResponse.SC_UNAUTHORIZED) {
                    LoginThrottle.recordFailure(throttleKey);
                }
            } catch (SQLException e) {
                LOG.log(Level.SEVERE, "Login failed: database error", e);
                status = HttpServletResponse.SC_SERVICE_UNAVAILABLE;
                error = "Sign-in is unavailable right now. Please try again shortly.";
            }
        }

        CsrfUtil.issue(req);
        req.setAttribute("error", error);
        req.setAttribute("email", email);
        resp.setStatus(status);
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }
}
