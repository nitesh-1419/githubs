package com.fleet.servlet;

import com.fleet.dao.UserDAO;
import com.fleet.util.CsrfUtil;
import com.fleet.util.PasswordUtil;
import java.io.IOException;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final Logger LOG = Logger.getLogger(RegisterServlet.class.getName());
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final String VIEW = "/WEB-INF/views/register.jsp";

    private final transient UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        CsrfUtil.issue(req);
        if ("1".equals(req.getParameter("expired"))) {
            Map<String, String> errors = new LinkedHashMap<>();
            errors.put("form", "Your page expired. Please submit the form again.");
            req.setAttribute("errors", errors);
        }
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        if (!CsrfUtil.isValid(req)) {
            resp.sendRedirect(req.getContextPath() + "/register?expired=1");
            return;
        }

        String name = trim(req.getParameter("name"));
        String email = trim(req.getParameter("email")).toLowerCase(Locale.ROOT);
        String password = req.getParameter("password") == null ? "" : req.getParameter("password");
        String confirm = req.getParameter("confirmPassword") == null ? "" : req.getParameter("confirmPassword");

        Map<String, String> errors = new LinkedHashMap<>();
        if (name.length() < 2 || name.length() > 100) {
            errors.put("name", "Enter your full name (2-100 characters).");
        }
        if (email.length() > 150 || !EMAIL.matcher(email).matches()) {
            errors.put("email", "Enter a valid e-mail address.");
        }
        if (password.length() < 8 || password.length() > 72
                || !password.matches(".*[A-Za-z].*") || !password.matches(".*\\d.*")) {
            errors.put("password", "Use 8-72 characters with at least one letter and one digit.");
        }
        if (!password.equals(confirm)) {
            errors.put("confirmPassword", "Passwords do not match.");
        }

        int status = HttpServletResponse.SC_BAD_REQUEST;
        if (errors.isEmpty()) {
            try {
                userDAO.createCustomer(name, email, PasswordUtil.hash(password));
                resp.sendRedirect(req.getContextPath() + "/login?registered=1");
                return;
            } catch (UserDAO.DuplicateEmailException e) {
                errors.put("email", "An account with this e-mail already exists.");
                status = HttpServletResponse.SC_CONFLICT;
            } catch (SQLException e) {
                LOG.log(Level.SEVERE, "Registration failed: database error", e);
                errors.put("form", "We couldn't create your account right now. Please try again shortly.");
                status = HttpServletResponse.SC_SERVICE_UNAVAILABLE;
            }
        }

        // Re-render with errors; never echo passwords back.
        CsrfUtil.issue(req);
        req.setAttribute("errors", errors);
        req.setAttribute("name", name);
        req.setAttribute("email", email);
        resp.setStatus(status);
        req.getRequestDispatcher(VIEW).forward(req, resp);
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }
}
