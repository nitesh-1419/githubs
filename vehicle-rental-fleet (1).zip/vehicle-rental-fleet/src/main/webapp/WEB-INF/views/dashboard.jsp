<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
  <title>Dashboard | Fleet</title>
  <%@ include file="/WEB-INF/jspf/head.jspf" %>
</head>
<body>
  <canvas id="grid-bg" aria-hidden="true"></canvas>

  <header class="topbar">
    <div class="brand mb-0"><span class="pip"></span>Fleet Optimization</div>
    <div class="d-flex align-items-center">
      <span><c:out value="${sessionScope.userName}"/></span>
      <span class="role-chip"><c:out value="${sessionScope.userRole}"/></span>
      <form method="post" action="${pageContext.request.contextPath}/logout" class="ms-3">
        <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">
        <button type="submit" class="btn-ghost">Sign out</button>
      </form>
    </div>
  </header>

  <main class="dash">
    <h1 class="h3 mb-1">Hello, <c:out value="${sessionScope.userName}"/></h1>
    <p class="text-secondary mb-4">You are signed in as <strong><c:out value="${sessionScope.userRole}"/></strong>. Next modules plug in here.</p>

    <div class="row g-3">
      <div class="col-md-4"><div class="tile"><span class="tag">Next</span><h3>Vehicle catalogue</h3><p>Browse and manage the fleet.</p></div></div>
      <div class="col-md-4"><div class="tile"><span class="tag">Next</span><h3>Bookings</h3><p>Availability checks and rental requests.</p></div></div>
      <div class="col-md-4"><div class="tile"><span class="tag">Next</span><h3>Fleet reports</h3><p>Utilization and maintenance insight.</p></div></div>
    </div>
  </main>

  <script src="${pageContext.request.contextPath}/assets/js/grid.js"></script>
</body>
</html>
