<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
  <title>Create account | Fleet</title>
  <%@ include file="/WEB-INF/jspf/head.jspf" %>
</head>
<body>
  <canvas id="grid-bg" aria-hidden="true"></canvas>

  <main class="stage">
    <section class="auth-card">
      <div class="brand"><span class="pip"></span>Fleet Optimization</div>
      <h1>Create your account</h1>
      <p class="lede">Register to browse vehicles and book rentals.</p>

      <c:if test="${not empty errors.form}"><div class="alert-fleet" role="alert"><c:out value="${errors.form}"/></div></c:if>

      <form method="post" action="${pageContext.request.contextPath}/register" novalidate data-validate>
        <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">

        <div class="mb-3">
          <label class="form-label" for="name">Full name</label>
          <input class="form-control ${not empty errors.name ? 'is-invalid' : ''}" type="text" id="name" name="name"
                 autocomplete="name" maxlength="100" value="<c:out value='${name}'/>" required autofocus>
          <div class="invalid-feedback"><c:out value="${errors.name}"/></div>
        </div>

        <div class="mb-3">
          <label class="form-label" for="email">E-mail</label>
          <input class="form-control ${not empty errors.email ? 'is-invalid' : ''}" type="email" id="email" name="email"
                 autocomplete="email" maxlength="150" placeholder="you@example.com" value="<c:out value='${email}'/>" required>
          <div class="invalid-feedback"><c:out value="${errors.email}"/></div>
        </div>

        <div class="mb-3">
          <label class="form-label" for="password">Password</label>
          <input class="form-control ${not empty errors.password ? 'is-invalid' : ''}" type="password" id="password"
                 name="password" autocomplete="new-password" maxlength="72" placeholder="8+ characters, letter and digit" required>
          <div class="invalid-feedback"><c:out value="${errors.password}"/></div>
          <div class="pw-meter" aria-hidden="true"><span></span></div>
        </div>

        <div class="mb-4">
          <label class="form-label" for="confirmPassword">Confirm password</label>
          <input class="form-control ${not empty errors.confirmPassword ? 'is-invalid' : ''}" type="password"
                 id="confirmPassword" name="confirmPassword" autocomplete="new-password" maxlength="72" required>
          <div class="invalid-feedback"><c:out value="${errors.confirmPassword}"/></div>
        </div>

        <button type="submit" class="btn btn-accent">Create account</button>
      </form>

      <p class="alt">Already registered? <a href="${pageContext.request.contextPath}/login">Sign in</a></p>
    </section>
  </main>

  <script src="${pageContext.request.contextPath}/assets/js/grid.js"></script>
  <script src="${pageContext.request.contextPath}/assets/js/auth.js"></script>
</body>
</html>
