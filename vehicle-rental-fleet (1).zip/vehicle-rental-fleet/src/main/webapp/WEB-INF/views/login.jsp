<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
  <title>Sign in | Fleet</title>
  <%@ include file="/WEB-INF/jspf/head.jspf" %>
</head>
<body>
  <canvas id="grid-bg" aria-hidden="true"></canvas>

  <main class="stage">
    <section class="auth-card">
      <div class="brand"><span class="pip"></span>Fleet Optimization</div>
      <h1>Welcome back</h1>
      <p class="lede">Sign in to manage rentals and your fleet.</p>

      <c:if test="${not empty success}"><div class="alert-fleet ok" role="status"><c:out value="${success}"/></div></c:if>
      <c:if test="${not empty error}"><div class="alert-fleet" role="alert"><c:out value="${error}"/></div></c:if>

      <form method="post" action="${pageContext.request.contextPath}/login" novalidate data-validate>
        <input type="hidden" name="_csrf" value="<c:out value='${csrfToken}'/>">

        <div class="mb-3">
          <label class="form-label" for="email">E-mail</label>
          <input class="form-control" type="email" id="email" name="email" autocomplete="username"
                 placeholder="you@example.com" value="<c:out value='${email}'/>" required autofocus>
          <div class="invalid-feedback"></div>
        </div>

        <div class="mb-4">
          <label class="form-label" for="password">Password</label>
          <input class="form-control" type="password" id="password" name="password"
                 autocomplete="current-password" placeholder="Your password" required>
          <div class="invalid-feedback"></div>
        </div>

        <button type="submit" class="btn btn-accent">Sign in</button>
      </form>

      <p class="alt">New customer? <a href="${pageContext.request.contextPath}/register">Create an account</a></p>
    </section>
  </main>

  <script src="${pageContext.request.contextPath}/assets/js/grid.js"></script>
  <script src="${pageContext.request.contextPath}/assets/js/auth.js"></script>
</body>
</html>
