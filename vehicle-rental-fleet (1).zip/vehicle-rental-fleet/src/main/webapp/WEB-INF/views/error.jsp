<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%
    Integer code = (Integer) request.getAttribute("javax.servlet.error.status_code");
    int status = code == null ? 500 : code;
    response.setStatus(status);
    String title = status == 404 ? "Page not found"
                 : status == 403 ? "Access denied"
                 : "Something went wrong";
    String text = status == 404 ? "The page you asked for does not exist."
                : status == 403 ? "You do not have permission to open this page."
                : "The request could not be completed. Please try again.";
    request.setAttribute("errTitle", title);
    request.setAttribute("errText", text);
    request.setAttribute("errCode", status);
%>
<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
  <title><c:out value="${errCode}"/> | Fleet</title>
  <%@ include file="/WEB-INF/jspf/head.jspf" %>
</head>
<body>
  <canvas id="grid-bg" aria-hidden="true"></canvas>
  <main class="stage">
    <section class="auth-card text-center">
      <div class="brand justify-content-center"><span class="pip"></span>Error <c:out value="${errCode}"/></div>
      <h1><c:out value="${errTitle}"/></h1>
      <p class="lede"><c:out value="${errText}"/></p>
      <a class="btn btn-accent" href="${pageContext.request.contextPath}/login">Back to sign in</a>
    </section>
  </main>
  <script src="${pageContext.request.contextPath}/assets/js/grid.js"></script>
</body>
</html>
