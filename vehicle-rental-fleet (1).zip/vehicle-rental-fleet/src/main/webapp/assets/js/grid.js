/*
 * Singularity dot grid -- Canvas 2D, no libraries.
 * One gaussian well drives everything: displacement, dot size/alpha, line alpha.
 */
(function () {
  'use strict';

  var canvas = document.getElementById('grid-bg');
  if (!canvas) return;
  var ctx = canvas.getContext('2d');

  var SPACING = 26;
  var ACCENT = '255,45,61';      // red
  var DOT = '236,236,242';       // near-white dots
  var EASE = 0.10;

  var width = 0, height = 0, cols = 0, rows = 0, dpr = 1;
  var grid = [];                 // grid[j][i] = { bx, by, x, y, g }

  var target = { x: 0, y: 0 };   // real pointer (CSS px)
  var tracked = { x: 0, y: 0 };  // eased pointer
  var pointerLive = false;       // true once a real (non-touch) pointer has entered
  var touchOnly = false;         // touch keeps the drift permanently

  function build() {
    cols = Math.floor(width / SPACING) + 2;
    rows = Math.floor(height / SPACING) + 2;
    var ox = (width - (cols - 1) * SPACING) / 2;
    var oy = (height - (rows - 1) * SPACING) / 2;
    grid = [];
    for (var j = 0; j < rows; j++) {
      var row = [];
      for (var i = 0; i < cols; i++) {
        var bx = ox + i * SPACING, by = oy + j * SPACING;
        row.push({ bx: bx, by: by, x: bx, y: by, g: 0 });
      }
      grid.push(row);
    }
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = canvas.clientWidth;
    height = canvas.clientHeight;
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    build();
  }

  new ResizeObserver(resize).observe(canvas);

  // --- pointer handling -------------------------------------------------
  window.addEventListener('pointermove', function (e) {
    if (e.pointerType === 'touch') { touchOnly = true; return; }
    pointerLive = true;
    target.x = e.clientX;
    target.y = e.clientY;
  }, { passive: true });
  window.addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'touch') touchOnly = true;
  }, { passive: true });
  document.addEventListener('pointerleave', function () { /* keep last position */ });

  // --- frame ------------------------------------------------------------
  var start = performance.now();
  var started = false;

  function frame(now) {
    var t = (now - start) / 1000;
    var m = Math.min(width, height);
    var SIG = 0.42 * m;
    var PULL = 0.30 * m;
    var twoSig2 = 2 * SIG * SIG;

    // Lissajous drift until a real pointer takes over (touch: permanent)
    if (!pointerLive || touchOnly) {
      target.x = width  * (0.5 + 0.34 * Math.sin(t * 0.7) * Math.cos(t * 0.23));
      target.y = height * (0.5 + 0.30 * Math.sin(t * 0.52 + 1.1));
    }
    if (!started) { tracked.x = target.x; tracked.y = target.y; started = true; }
    tracked.x += (target.x - tracked.x) * EASE;
    tracked.y += (target.y - tracked.y) * EASE;

    // Displace every point
    var px = tracked.x, py = tracked.y;
    for (var j = 0; j < rows; j++) {
      var row = grid[j];
      for (var i = 0; i < cols; i++) {
        var p = row[i];
        var dx = px - p.bx, dy = py - p.by;
        var d = Math.sqrt(dx * dx + dy * dy);
        var g = Math.exp(-(d * d) / twoSig2);
        p.g = g;
        if (d > 0.0001) {
          // Pull along own direction toward the pointer; never overshoot it.
          var move = Math.min(g * PULL, d);
          p.x = p.bx + (dx / d) * move;
          p.y = p.by + (dy / d) * move;
        } else {
          p.x = p.bx; p.y = p.by;
        }
      }
    }

    ctx.clearRect(0, 0, width, height);

    // Lines: to the right and below
    ctx.lineWidth = 1;
    for (j = 0; j < rows; j++) {
      for (i = 0; i < cols; i++) {
        var a = grid[j][i];
        if (i < cols - 1) strokeLink(a, grid[j][i + 1]);
        if (j < rows - 1) strokeLink(a, grid[j + 1][i]);
      }
    }

    // Dots
    for (j = 0; j < rows; j++) {
      for (i = 0; i < cols; i++) {
        var q = grid[j][i];
        ctx.fillStyle = 'rgba(' + DOT + ',' + (0.16 + q.g * 0.62).toFixed(3) + ')';
        ctx.beginPath();
        ctx.arc(q.x, q.y, 0.9 + q.g * 1.9, 0, 6.283185307);
        ctx.fill();
      }
    }

    requestAnimationFrame(frame);
  }

  function strokeLink(a, b) {
    var avg = (a.g + b.g) * 0.5;
    if (avg < 0.004) return;                    // keep the far field clean
    ctx.strokeStyle = 'rgba(' + ACCENT + ',' + (0.04 + avg * 0.62).toFixed(3) + ')';
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  resize();
  requestAnimationFrame(frame);
})();
