/* Client-side validation (UX only -- the servlets re-validate everything). */
(function () {
  'use strict';

  var form = document.querySelector('form[data-validate]');
  if (!form) return;

  function setInvalid(input, message) {
    input.classList.add('is-invalid');
    var fb = input.parentNode.querySelector('.invalid-feedback');
    if (fb && message) fb.textContent = message;
  }

  var pw = form.querySelector('#password');
  var meter = form.querySelector('.pw-meter span');
  if (pw && meter) {
    pw.addEventListener('input', function () {
      var v = pw.value, s = 0;
      if (v.length >= 8) s++;
      if (/[A-Za-z]/.test(v) && /\d/.test(v)) s++;
      if (v.length >= 12) s++;
      if (/[^A-Za-z0-9]/.test(v)) s++;
      meter.style.width = (s * 25) + '%';
    });
  }

  form.addEventListener('submit', function (e) {
    var ok = true;
    form.querySelectorAll('.is-invalid').forEach(function (el) { el.classList.remove('is-invalid'); });

    var name = form.querySelector('#name');
    if (name && name.value.trim().length < 2) { setInvalid(name, 'Enter your full name.'); ok = false; }

    var email = form.querySelector('#email');
    if (email && !/^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/.test(email.value.trim())) {
      setInvalid(email, 'Enter a valid e-mail address.'); ok = false;
    }

    var confirm = form.querySelector('#confirmPassword');
    if (pw && confirm) {                              // registration only
      if (pw.value.length < 8 || !/[A-Za-z]/.test(pw.value) || !/\d/.test(pw.value)) {
        setInvalid(pw, 'Use 8+ characters with a letter and a digit.'); ok = false;
      }
      if (pw.value !== confirm.value) { setInvalid(confirm, 'Passwords do not match.'); ok = false; }
    } else if (pw && !pw.value) {                     // login
      setInvalid(pw, 'Enter your password.'); ok = false;
    }

    if (!ok) { e.preventDefault(); return; }
    var btn = form.querySelector('button[type=submit]');   // block accidental double submits
    if (btn) { btn.disabled = true; btn.textContent = 'Please wait...'; }
  });
})();
