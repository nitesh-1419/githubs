-- Vehicle Rental & Fleet Optimization System -- authentication schema
-- Run:  mysql -u root -p < sql/schema.sql

CREATE DATABASE IF NOT EXISTS fleet_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fleet_db;

CREATE TABLE IF NOT EXISTS users (
    user_id       INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    name          VARCHAR(100)  NOT NULL,
    email         VARCHAR(150)  NOT NULL,
    password_hash VARCHAR(255)  NOT NULL,           -- pbkdf2$iterations$salt$hash (never plain text)
    role          ENUM('CUSTOMER','STAFF','ADMIN') NOT NULL DEFAULT 'CUSTOMER',
    status        ENUM('ACTIVE','SUSPENDED')       NOT NULL DEFAULT 'ACTIVE',
    created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB;

-- Public registration always creates CUSTOMER accounts.
-- Promote the first administrator manually after registering them:
--   UPDATE users SET role = 'ADMIN' WHERE email = 'you@example.com';

-- Optional: a least-privilege application login instead of root (then set DB_USER / DB_PASSWORD).
--   CREATE USER 'fleet_app'@'localhost' IDENTIFIED BY 'change-me';
--   GRANT SELECT, INSERT, UPDATE, DELETE ON fleet_db.* TO 'fleet_app'@'localhost';
